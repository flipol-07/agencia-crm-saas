import type { Metadata, Viewport } from 'next'
import './globals.css'
import { Toaster } from 'sonner'
import { DevServiceWorkerCleaner } from '@/shared/components/devtools/DevServiceWorkerCleaner'

export const metadata: Metadata = {
  title: 'Aurie CRM',
  description: 'Sistema de gestión integral para agencias',
  manifest: '/manifest.webmanifest',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Aurie CRM',
    startupImage: [
      '/brand/logo.png',
    ],
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
  themeColor: '#000000',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" data-scroll-behavior="smooth" suppressHydrationWarning>
      <body>
        {children}
        <Toaster richColors position="top-center" />
        <DevServiceWorkerCleaner />
      </body>
    </html>
  )
}

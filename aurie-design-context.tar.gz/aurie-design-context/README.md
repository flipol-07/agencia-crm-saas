# Aurie CRM — Frontend / Design Context

Curated subset for Claude Design.

## Stack
- Next.js 16 App Router + React 19 + TypeScript
- Tailwind CSS 3.4
- Framer Motion for animations
- Supabase for data (do not redesign data fetching, just UI)

## Current direction (to evolve)
- Dark theme with heavy purple gradients (#8b5cf6) and glass-morphism
- Fonts: Outfit (display) + Inter (body) — open to changes

## Target direction
EDITORIAL / MAGAZINE: distinctive serif display, warm dark background,
single warm accent (NOT purple), large numerical KPIs, generous whitespace,
asymmetric layouts. Premium feel for B2B agency.

## Files
- `tailwind.config.ts` + `app/globals.css` — current design tokens
- `app/layout.tsx` — root shell
- `brand/` — logos
- `shared/ui/` — primitives (Button, Card, Badge, Tooltip, Skeleton)
- `shared/layout/` — Sidebar, Header, MobileNav, GlassSidebar
- `pages/` — current full pages (dashboard, pipeline, contacts, login)
- `components/dashboard/` — KPI cards, alerts panel, forecast, aging, top deals, Aura prompts
- `components/pipeline/` — kanban + stats bar

## What to redesign
Goal: keep all data shown today, restyle everything to Editorial direction.
Output: React+Tailwind code I can paste into the project.
